# Python Fundamentals 
 
